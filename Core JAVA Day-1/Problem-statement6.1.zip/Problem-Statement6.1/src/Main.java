import java.util.LinkedList;

public class Main {
	
	public static void main(String[] args) {
		
		LinkedList<String> a = new LinkedList<String>();
		a.add("Alpha");
		a.add("Beta");
		a.add("Cappa");
		a.add("Delta");
		a.add("Foxtrot");
		
		System.out.println("Linked List --> " + a);
		
		
		if(a.contains("Foxtrot")) {
			System.out.println("Foxtrot is present in the Linked List");
			
		}else {
			System.out.println("Foxtrot is not present in the Linked List");
		}
		
			if(a.contains("Golf")) {
				System.out.println("Golf is present in the Linked List");
				
			}else {
				System.out.println("Golf is not present in the Linked List");
			
			
		
		}
	}

	

}
