import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
	
	public static void main(String[] args) {
		
	
	
	String myString;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter String: ");
	myString = sc.nextLine();
	
	String[] result = myString.split("(?<=[-+*/])|(?=[-+*/])");
	System.out.println(Arrays.toString(result));
	//System.out.println(Arrays.toString(myString.split("(?<=[-+*/])")));
	
}
}

