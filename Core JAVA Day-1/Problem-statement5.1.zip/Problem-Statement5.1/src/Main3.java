
public class Main3 {
	
	public static void main(String[] args) {
		
		String str = "JAVA is Simple";
		String[ ] words = str.split(" ");
		String reverse = " ";
		
		for(int i = 0 ; i < words.length; i++)
		{
			for(int j = words[i].length()-1; j>=0;j--)
			{
				reverse += words[i].charAt(j);
			}
			System.out.println(reverse+ " ");
			reverse = " ";
		}
	}

}
