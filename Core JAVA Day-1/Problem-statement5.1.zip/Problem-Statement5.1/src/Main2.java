
public class Main2 {
	
	public static String reverseName(String name) {
		name = name.trim();
		
		StringBuilder reversedNameBuilder = new StringBuilder();
		StringBuilder subNameBuilder = new StringBuilder();
		
		for(int i = 0; i < name.length(); i++ )
		{
			char currentChar = name.charAt(i);
			
			if(currentChar != ' ' && currentChar != '-')
			{
				subNameBuilder.append(currentChar);
			}else {
				reversedNameBuilder.insert(0, currentChar + subNameBuilder.toString());
				subNameBuilder.setLength(0);
			}
		}
		
		return reversedNameBuilder.insert(0, subNameBuilder.toString()).toString();
	}
	
	public static void main(String[] args) {
		
		printTest("JAVA is Simple");
	}
	
	private static void printTest(String s)
	{
		System.out.printf("Reverse name for %s: %s\n", s, reverseName(s));
	}

}
