
public class ManiString {
	
	public static void main(String[] args) {
		
		String str = "JAVA is Simple";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		/**String initials = "";
		for(String s : str.split(" ")) {
			initials+=s.charAt(0);
			System.out.println(s);
		}**/
		String myString = "JAVA is Simple";
		System.out.println(myString.replace(" ", "").length());
		//System.out.println(str.length());
		//System.out.println();
		
	}

}
