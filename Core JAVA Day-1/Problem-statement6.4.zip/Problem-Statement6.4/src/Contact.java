
public class Contact {
	
	private String firstName;
	private String lastname;
	private long phoneNumber;
	private String emailId;
	
	public Contact() {
		// TODO Auto-generated constructor stub
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "Contact [firstName=" + firstName + ", lastname=" + lastname + ", phoneNumber=" + phoneNumber
				+ ", emailId=" + emailId + ", getFirstName()=" + getFirstName() + ", getLastname()=" + getLastname()
				+ ", getPhoneNumber()=" + getPhoneNumber() + ", getEmailId()=" + getEmailId() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	public Contact(String firstName, String lastname, long phoneNumber, String emailId) {
		super();
		this.firstName = firstName;
		this.lastname = lastname;
		this.phoneNumber = phoneNumber;
		this.emailId = emailId;
	}
	
	
	

}
