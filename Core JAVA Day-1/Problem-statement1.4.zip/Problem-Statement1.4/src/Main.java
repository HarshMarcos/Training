import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Rec obj = new Rec();
		Scanner sc = new Scanner(System.in);
		
		float len,wid;
		System.out.println("Enter the length of the Rectangle");
		len = sc.nextFloat();
		System.out.println("Enter the width of the Rectangle");
		wid = sc.nextFloat();
		obj.setLEngth(len);
		obj.setWidth(wid);
		System.out.println("Length of the triangle is: "+obj.getLength());
		System.out.println("Width of the triangle is: "+obj.getWidth());
		System.out.println("Area of the triangle is: "+obj.area());
		System.out.println("Perimeter of the triangle: "+obj.perimeter());
	}

}
