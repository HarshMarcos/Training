import java.util.Scanner;

class Rectangle{
	private int length;
	private int breadth;
	private int area;
	
	void input() {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
		
		
	}
	
	void printData() {
		Scanner in = new Scanner(System.in);
		System.out.println("Length: " + length);
		length = in.nextInt();
		System.out.println("Breadth: " + breadth);
		breadth = in.nextInt();
		
	}
	
	void printArea() {
		
		int area = length * breadth ; 
		System.out.println("Area: " + area);
	}
	
	
}
