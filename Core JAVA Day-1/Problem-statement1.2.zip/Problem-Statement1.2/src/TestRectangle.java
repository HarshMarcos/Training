
public class TestRectangle {
	
	public static void main(String[] args) {
		
		Rectangle obj = new Rectangle();
		obj.printData();
		obj.printArea();
		
		Rectangle obj2 = new Rectangle();
		obj.printData();
		obj.printArea();
		
		Rectangle obj3 = new Rectangle();
		obj.printData();
		obj.printArea();
		
		Rectangle obj4 = new Rectangle();
		obj.printData();
		obj.printArea();
		
		Rectangle obj5 = new Rectangle();
		obj.printData();
		obj.printArea();
		
		
		
	}

}
