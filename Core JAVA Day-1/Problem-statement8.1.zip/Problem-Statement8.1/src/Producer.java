
class Producer implements Runnable{
	MyQueue q;
	Producer(MyQueue q){
		this.q = q;
	}
	public void run() {
		int i =0;
		while(true) {
			q.put(i++);
		}
	}
}