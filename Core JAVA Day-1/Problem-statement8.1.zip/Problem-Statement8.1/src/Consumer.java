
public class Consumer implements Runnable {
	
	MyQueue q;
	public Consumer(MyQueue q) {
		this.q = q;
		// TODO Auto-generated constructor stub
	}
	public void run() {
		while(true) {
			q.get();
		}
	}

}
