import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
	
	public static void main(String[] args) {
		
		System.out.println("Press Control-C to Stop");
		ExecutorService service = Executors.newFixedThreadPool(2);
		
		MyQueue q = new MyQueue();
		service.execute(new Producer(q));
		service.execute(new Consumer(q));
	}

}
