
public class Average { 
	
	
	
	public static void main(String[] args) {
		
		int A [] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int length = A.length;
		int sum = 0;
		for(int i = 0; i < A.length; i++)
			sum += A[i]; 
		
		
		
		double average = sum / length;
		
		System.out.println("Average of array : " + average);
		
		A[A.length-2]=(int) average;
		System.out.println(average);
		
		
		
	
			
	}
	


	

}
