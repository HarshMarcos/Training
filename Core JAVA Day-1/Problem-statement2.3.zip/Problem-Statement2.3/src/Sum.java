
public class Sum {
	
	static void sumRange(int li[], int a, int b)
	{
		int sum = 0;
		boolean add = true;
		
		for(int i =0; i < li.length; i++)
		{
			
			if(li[i] != a && add==true)
				sum = sum +li[i];
			
			else if(li[i] == a)
				add =false;
			else if(li[i]==b)
				add = true;
		}
		System.out.println(sum);
		
	
	}
	
	public static void main(String[] args) {
		
		int lis[ ] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int a = 15;
		int b = 17;
		sumRange(lis,a,b);
	}

}
