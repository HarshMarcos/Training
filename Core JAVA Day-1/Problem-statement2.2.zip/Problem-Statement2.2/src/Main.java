import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
	System.out.println("Enter the term to be printed : ");
	Scanner ob = new Scanner(System.in);
	int ch = ob.nextInt();
	System.out.println("Enter the 1 No : ");
	int a = ob.nextInt();
	System.out.println("Enter the 2 No : ");
	int b = ob.nextInt();
	int s;
	for(int n = 1; n <= ch ; n++) {
		System.out.println(a);
		//System.out.println(b);
		
		s = a + b;
		a = b;
		b = s;
		
		
		
	}
		
		
		
		
		
		
	}

}
