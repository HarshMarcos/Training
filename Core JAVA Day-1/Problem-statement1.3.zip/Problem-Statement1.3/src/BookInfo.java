import java.util.Scanner;

public class BookInfo {
	

	public static void main(String[] args) {
		
		Book b1 = new Book("Java Programming", 350.50);
		b1.show();
		
		Book b2 = new Book("Let Us C", 200);
		b2.show();
		
	/**	Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Book name:  ");
		String bookname = sc.nextLine();
		
		System.out.println("Enter the price: ");
		float price = sc.nextFloat();
		sc.nextLine();
		
		
		Book obj = new Book(bookname, price);
		obj.setBook_title(bookname);
		obj.setBook_price(price);
		System.out.println(obj.getBook_title() + " Rs "+obj.getBook_price());
		Book obj1 = new Book(bookname, price);
		obj.setBook_title(bookname);
		obj.setBook_price(price);
		System.out.println(obj1.getBook_title()+" Rs." +obj1.getBook_price());**/
		
		
		
		
		
	}

}
