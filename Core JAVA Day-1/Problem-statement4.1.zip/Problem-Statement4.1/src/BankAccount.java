
public class BankAccount {
	
	private int accNo;
	private String custName;
	private String accType;
	private float balance;
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	public boolean withdraw(int w)
	{
		if(getBalance()<w)
		{
			System.out.println("Insufficient Funds");
			return false;
		}
		else
		{
			System.out.println("Balance amount withdraw: "+ (getBalance()-w));
			return true;
		}
	}
	
	
	

}
