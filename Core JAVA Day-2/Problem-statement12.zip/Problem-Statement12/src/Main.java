import java.util.HashSet;

public class Main {
	
	static void printfirstRepeating(int arr[])
	{
		int min = -1;
		
		HashSet<Integer> set = new HashSet<>();
		
		 for (int i=arr.length-1; i>=0; i--)
	        {
	          
	            if (set.contains(arr[i]))
	                min = i;
	 
	            else  
	                set.add(arr[i]);
	        }
		 
		 if(min != -1)
			 System.out.println("First Repeated Element is:" + arr[min]);
		 else
			 System.out.println("There is no repeating element");
	}
	
	public static void main(String[] args) {
		
		int arr[] = { 1, 2, 3, 10, 2, 4, 5, 7, 8 };
		printfirstRepeating(arr);
	}

}
