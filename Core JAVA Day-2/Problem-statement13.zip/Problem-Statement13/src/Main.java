import java.util.Scanner;

class Node
{
    int data;
    Node next;
 
    Node(int data, Node next)
    {
        this.data = data;
        this.next = next;
    }
}
 
class Main
{
    // Iterative function to return the k'th node from the end in a linked list
    public static Node findKthNode(Node head, int k)
    {
        int n = 0;
        Node curr = head;
 
        // count the total number of nodes in the linked list
        while (curr != null)
        {
            curr = curr.next;
            n++;
        }
 
        // if the total number of nodes is more than or equal to `k`
        if (n >= k)
        {
            // return (n-k+1)'th node from the beginning
            curr = head;
            for (int i = 0; i < n - k; i++) {
                curr = curr.next;
            }
        }
 
        return curr;
    }
 
    public static void main(String[] args)
    {
        // input keys
        //int[] keys = { 1, 2, 3, 4, 5 };
    	Scanner sc = new Scanner(System.in);
		System.out.println("Input the number od nodes: ");
		int size = sc.nextInt();
		
		System.out.println("Please input data for node: ");
		int keys[] = new int[ size];
		for(int i = 0; i < size; i++)
		{
			keys[i] = sc.nextInt();
		}
        
        
 
        Node head = null;
        for (int i = keys.length - 1; i >= 0; i--) {
            head = new Node(keys[i], head);
        }
 
        int k = 3;
        Node node = findKthNode(head, size);
 
        if (node != null) {
            System.out.println("k'th node from the end is " + node.data);
        }
    }
}