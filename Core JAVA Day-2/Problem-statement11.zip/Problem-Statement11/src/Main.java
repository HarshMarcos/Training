import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
	int V = 0;
	Scanner x = new Scanner(System.in);
	System.out.println("Enter a no : ");
	V = x.nextInt();
	
	ArrayList<Integer> ans = new ArrayList <>();
	int coins [] = {1, 2, 5, 10, 20, 50, 100, 500, 1000};
	int n = coins.length;
	for(int i = n - 1; i >= 0; i--)
	{
		while(V >= coins[i]) {
			V -= coins[i];
			ans.add(coins[i]);
		}
	}
	for(int i =0; i < ans.size(); i++)
	System.out.println(ans.size()+". BreakDown- "+ans.get(i));
	System.out.println("");
	

}
}

