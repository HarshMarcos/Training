import java.util.Scanner;

public class Main {
	
	static int stairs(int n)
	{
		if(n <= 1)
			return n;
		return stairs(n-1) + stairs(n-2);
	}
	
	static int countWays(int s)
	{
		return stairs(s + 1);
	}
	
	public static void main(String[] args) {
		int a;
		Scanner sc = new Scanner(System.in);
		System.out.println("n= ");
		a = sc.nextInt();
		System.out.println(countWays(a));
	}

}
