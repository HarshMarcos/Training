import java.util.HashMap;
import java.util.Scanner;
import java.util.function.Function;

public class Main {
	
	static String fucntion(int numr, int denr)
	{
		String res = "";
		
		HashMap<Integer, Integer> mp = new HashMap<>();
		mp.clear();
		
		int rem = numr % denr;
		
		while((rem != 0) && (!mp.containsKey(rem)))
		{
			mp.put(rem, res.length());
			
			rem = rem * 10;
			int res_part = rem / denr;
			
			 res += String.valueOf(res_part);
			
			rem = rem % denr;
		}
		
		if(rem == 0)
			return "";
		else if(mp.containsKey(rem))
			return res.substring(mp.get(rem));
			
		return "";
		}
	
	public static void main(String[] args) {
		
		int numr = 0 ,denr = 0  ;
		Scanner sc = new Scanner(System.in);
		System.out.println("(" +numr+","+denr+ ")");
		numr = sc.nextInt();
		denr = sc.nextInt();
		
		String res = fucntion(numr,denr);
		if(res == "")
			System.out.println("->There is no repeating decimal no brackets");
		else
			System.out.println(res+"->here "+res+" is repeating decimal, put it in brackets");
		
	}

}
